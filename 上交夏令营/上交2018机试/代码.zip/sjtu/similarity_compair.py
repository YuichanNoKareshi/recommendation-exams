# -*- coding: utf-8 -*-

import sys
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtWidgets import QFileDialog
import numpy as np
import matplotlib.cm as cm
import matplotlib.pyplot as plt
from pylab import mpl

# 保存文本名称
text_name = ''

# UI前端界面
class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1280, 800)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(420, 10, 54, 21))
        self.label.setObjectName("label")
        self.fileInput = QtWidgets.QLineEdit(self.centralwidget)
        self.fileInput.setGeometry(QtCore.QRect(470, 10, 111, 21))
        self.fileInput.setObjectName("fileInput")
        self.chooseButton = QtWidgets.QPushButton(self.centralwidget)
        self.chooseButton.setGeometry(QtCore.QRect(610, 10, 75, 23))
        self.chooseButton.setObjectName("chooseButton")
        self.detectButton = QtWidgets.QPushButton(self.centralwidget)
        self.detectButton.setGeometry(QtCore.QRect(710, 10, 75, 23))
        self.detectButton.setObjectName("detectButton")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1280, 23))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        # 按钮绑定函数
        self.chooseButton.clicked.connect(self.open_text)
        self.detectButton.clicked.connect(self.process_text)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "数据真实性检测工具"))
        self.label.setText(_translate("MainWindow", "数据文件"))
        self.chooseButton.setText(_translate("MainWindow", "选择"))
        self.detectButton.setText(_translate("MainWindow", "检测"))

    # 打开文本
    def open_text(self):
        # 使用PyQt打开文件对话框
        global text_name
        text_info = QFileDialog.getOpenFileName(QtWidgets.QMainWindow(), '选择文件', '',
                                                'Text files(*.csv)')
        text_name = text_info[0]
        if text_name != '':
            self.fileInput.setText(text_name)
        print(text_name)

    # 检测文本，输出结果
    def process_text(self):
        # 判断文件格式是否有误
        global text_name
        text_name = self.fileInput.text()
        if text_name == '' or str(text_name.split('.')[-1]) != 'csv':
            self.open_text()
            return
        try:
            file = open(text_name, encoding='utf8')
        except:
            self.open_text()
            return

        # 从csv文件中读取数据
        strCache = []
        flag = True
        while True:
            line = file.readline()
            if len(line) == 0:
                break
            if flag == True:
                line = line[1:]
                flag = False
            strCache.append(line)
        file.close()

        # 程序主要逻辑
        lineSum = len(strCache)
        firstCopyCount = 0
        secondCopyCount = 0
        plt.figure(figsize=(10, 6))
        for i in range(0, 4):
            coef = int(lineSum * i / 4)
            cache1 = strCache[coef:coef + int(lineSum / 8)]
            cache2 = strCache[coef + int(lineSum / 8):coef + int(lineSum / 4)]
            firstCopyCount = firstCopyCount + get_similarity_matrix(cache1, cache2, int(lineSum / 8), i + 1)
            # 翻转后一个序列
            cache3 = strCache[coef + int(lineSum / 4):coef + int(lineSum / 8):-1]
            secondCopyCount = secondCopyCount + get_similarity_matrix(cache1, cache3, int(lineSum / 8), i + 5)
            # 翻转前一个序列
            # cache3 = strCache[coef+int(lineSum/8):coef:-1]
            # secondCopyCount = secondCopyCount + get_similarity_matrix(cache3, cache2, int(lineSum / 8), i + 5)

        mpl.rcParams['font.sans-serif'] = ['SimHei']  # 指定默认字体
        plt.text(-300, -120, '直接二分')
        plt.text(-300, -22, '直接复制' + str(firstCopyCount) + '处')
        plt.text(-300, -8, '对称二分')
        plt.text(-300, 90, '逆序复制' + str(secondCopyCount) + '处')
        plt.show()

        print('直接复制' + str(firstCopyCount) + '处')
        print('逆序复制' + str(secondCopyCount) + '处')


def get_s(a, b):
    if a == b:
        return 3
    else:
        return -1

# 获取相似度矩阵
def get_similarity_matrix(listA, listB, batch, count):
    similarity_matrix = np.zeros((len(listB) + 1, len(listA) + 1), dtype='int')
    row = similarity_matrix.shape[0]
    col = similarity_matrix.shape[1]
    for i in range(1, row):
        for j in range(1, col):
            similarity_matrix[i][j] = max(similarity_matrix[i - 1][j - 1] + get_s(listB[i - 1], listA[j - 1]),
                                          similarity_matrix[i][j - 1] - 1, similarity_matrix[i - 1][j] - 1, 0)
    print('figure:' + str(count))
    copyCount = 0
    similarity_matrix = similarity_matrix[row:1:-1, 1:col]
    plt.subplot(240 + int(count))
    plt.xticks(np.arange(0, batch * count, batch / 5), np.arange(batch * (count - 1), batch * count, int(batch / 5)))
    plt.yticks(np.arange(0, batch * count, batch / 5), np.arange(batch * count, batch * (count - 1), int(-batch / 5)))
    plt.imshow(similarity_matrix, cmap=cm.hot)
    for i in range(0, len(similarity_matrix)):
        for j in range(0, len(similarity_matrix[i])):
            if (similarity_matrix[i][j] > 5):   # 阈值硬编码为5
                copyCount = copyCount + 1
            print(str(similarity_matrix[i][j]) + ' ', end='')
        print('\n')
    return copyCount

# 主程序开始
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
